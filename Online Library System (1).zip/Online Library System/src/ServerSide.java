import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ServerSide extends Thread {

    private static ArrayList<ClientHandler> clients = new ArrayList<>();
    private static Map<String, Integer> books = new HashMap<>();

    public static void main(String[] args) {
        books.put("The Lord of the Rings", 1);
        books.put("Harry Potter", 1);
        books.put("The Hunger Games", 1);
        books.put("The Witcher", 1);
        books.put("The Divergent", 1);
        books.put("Sherlock Holmes", 1);


        if (args.length != 1) {
            System.err.println("Usage: java ServerSide <portNumber>");
            System.exit(1);
        }
        int portNumber = Integer.parseInt(args[0]);

        try (ServerSocket serverSocket = new ServerSocket(portNumber)) {
            System.out.println("Server started, waiting for clients...");

            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("New Client connected");

                ClientHandler clientThread = new ClientHandler(clientSocket);
                clients.add(clientThread);
                new Thread(clientThread).start();
            }
        } catch (IOException e) {
            System.out.println("Exception on port " + portNumber);
            e.printStackTrace();
        }
    }

    public synchronized static String borrowingBooks(String bookName) {
        if (books.containsKey(bookName) && books.get(bookName) > 0) {
            books.put(bookName, books.get(bookName) - 1);
            String message = bookName + " has been borrowed";
            broadcastUpdate(message);
            return "You have borrowed the book: \"" + bookName + "\"";
        } else {
            return "\"" + bookName + "\" is not available right now";
        }
    }

    public synchronized static String returningBooks(String bookName) {
        if (books.containsKey(bookName)) {
            books.put(bookName, books.get(bookName) + 1);
            String message = bookName + " has been returned";
            broadcastUpdate(message);
            return "You have returned the book: \"" + bookName + "\"";
        } else {
            return "\"" + bookName + "\" does not belong to this library";
        }
    }
    public synchronized static String searchingBooks(String searchTerm) {
        StringBuilder sb = new StringBuilder();
        sb.append("Search Results for \"").append(searchTerm).append("\": ");
        boolean first = true;
        for (String book : books.keySet()) {
            if (book.toLowerCase().contains(searchTerm.toLowerCase())) {
                if (!first) {
                    sb.append(" | ");
                }
                int available = books.get(book);
                sb.append(book).append(" - Available: ").append(available);
                first = false;
            }
        }
        if (first) {
            sb.append("No books found matching the search term.");
        }
        return sb.toString();
    }


    public synchronized static void broadcastUpdate(String message) {
        for (ClientHandler client : clients) {
            client.sendMessageToClient("UPDATE:" + message); // Ensure no extra spaces
        }
    }

    public synchronized static String viewingBooks() {
        return books.toString();
    }
}
