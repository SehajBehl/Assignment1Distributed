import java.io.*;
import java.net.Socket;

public class ClientHandler implements Runnable {
    private Socket client;
    private BufferedReader in;
    private PrintWriter out;

    public ClientHandler(Socket clientSocket) throws IOException {
        this.client = clientSocket;
        in = new BufferedReader(new InputStreamReader(client.getInputStream()));
        out = new PrintWriter(client.getOutputStream(), true);
    }

    @Override
    public void run() {
        try {
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                System.out.println("Received: " + inputLine);
                String[] parts = inputLine.split(" ", 2);
                String command = parts[0].toLowerCase();

                String response;
                switch (command) {
                    case "view":
                        response = ServerSide.viewingBooks();
                        break;
                    case "borrow":
                        response = (parts.length > 1) ? ServerSide.borrowingBooks(parts[1]) : "Please specify a book name.";
                        break;
                    case "return":
                        response = (parts.length > 1) ? ServerSide.returningBooks(parts[1]) : "Please specify a book name.";
                        break;
                    case "search":
                        response = (parts.length > 1) ? ServerSide.searchingBooks(parts[1]) : "Please specify a search term.";
                        break;
                    default:
                        response = "Unknown command. Use: view, borrow <book name>, return <book name>";
                }
                out.println("RESPONSE:" + response); // Removed the space after "RESPONSE:"
            }
        } catch (IOException e) {
            System.err.println("Error handling client input/output");
            e.printStackTrace();
        } finally {
            try {
                in.close();
                out.close();
                client.close();
            } catch (IOException e) {
                System.out.println("Error closing resources");
            }
        }
    }

    public void sendMessageToClient(String message) {
        out.println(message);
    }
}
