import java.io.*;
import java.net.*;
import java.util.Scanner;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class ClientSide {
    public static void main(String[] args) {
        if (args.length != 2) {
            System.err.println("Usage: java ClientSide <host name> <port number>");
            System.exit(1);
        }

        String hostName = args[0];
        int portNumber = Integer.parseInt(args[1]);

        try (
                Socket librarySocket = new Socket(hostName, portNumber);
                PrintWriter out = new PrintWriter(librarySocket.getOutputStream(), true);
                BufferedReader in = new BufferedReader(new InputStreamReader(librarySocket.getInputStream()))
        ) {
            System.out.println("Connected to Library Server.");


            BlockingQueue<String> responseQueue = new LinkedBlockingQueue<>();


            Thread readerThread = new Thread(() -> {
                try {
                    String serverMessage;
                    while ((serverMessage = in.readLine()) != null) {
                        if (serverMessage.startsWith("UPDATE:")) {
                            synchronized (System.out) {
                                System.out.println("\n[Server Update]: " + serverMessage.substring(7));
                                System.out.print("Enter command (view, borrow <book name>, return <book name>, search <search term>): ");
                            }
                        } else if (serverMessage.startsWith("RESPONSE:")) {
                            responseQueue.put(serverMessage.substring(9));
                        }
                    }
                } catch (IOException e) {
                    System.out.println("Disconnected from server.");
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            });
            readerThread.start();


            Scanner scanner = new Scanner(System.in);
            while (true) {
                System.out.print("Enter command (view, borrow <book name>, return <book name>, search <search term>): ");
                String userCommand = scanner.nextLine();
                out.println(userCommand);


                String response = responseQueue.take();
                System.out.println(response);
            }
        } catch (UnknownHostException e) {
            System.err.println("Don't know about host " + hostName);
            System.exit(1);
        } catch (IOException e) {
            System.err.println("Couldn't get I/O for the connection to " + hostName);
            System.exit(1);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
